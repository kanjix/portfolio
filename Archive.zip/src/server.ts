import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, { Request, Response, NextFunction } from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

/**
 * Статические файлы из /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Обработка всех остальных запросов через Angular Engine
 */
// Добавляем типы Request, Response и NextFunction для устранения ошибок TS
app.use((req: Request, res: Response, next: NextFunction) => {
  angularApp
    .handle(req)
    .then((response: Response | null) => 
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch((err: unknown) => next(err));
});

/**
 * Запуск сервера
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, () => {
    // В современных версиях Express listen не передает error в callback
    // Для отлова ошибок запуска используют app.on('error', ...)
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Экспорт обработчика для Angular CLI или Cloud Functions
 */
export const reqHandler = createNodeRequestHandler(app);